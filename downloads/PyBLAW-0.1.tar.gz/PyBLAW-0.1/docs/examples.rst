PyBLAW Examples
===============

Linear system
-------------

.. literalinclude:: ../examples/linear.py


Shallow-water solver
--------------------

.. literalinclude:: ../examples/shallow_water.py


Plotting the output
-------------------

.. literalinclude:: ../examples/plot.py
